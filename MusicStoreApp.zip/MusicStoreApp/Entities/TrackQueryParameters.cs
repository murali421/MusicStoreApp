﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStoreApp.Entities
{
    public class TrackQueryParameters : PageQueryParameters
    {        
        public string Name { get; set; }
    }
}
