﻿using MusicStoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStoreApp.Repository
{
    public class RepositoryFacade : IRepositoryFacade
    {
        private MusicStoreDBContext _repoContext;
        private TrackRepository _track;

        public RepositoryFacade(MusicStoreDBContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }

        public TrackRepository Track
        {
            get
            {
                if (_track == null)
                {
                    _track = new TrackRepository(_repoContext);
                }

                return _track;
            }
        }

    }
}
