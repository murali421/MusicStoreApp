﻿using MusicStoreApp.Entities;
using MusicStoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace MusicStoreApp.Repository
{
    public class TrackRepository : BaseRepository<Track> 
    {
        public TrackRepository(MusicStoreDBContext musicStoreDBContext)
            : base(musicStoreDBContext)
        {
        }

        public IQueryable<Track> Get()
        {
            IQueryable<Track> tracks = GetAll();
            return tracks.Include(x => x.Artist).OrderBy(x => x.TrackId);
        }

        public IQueryable<Track> GetByExpression(Expression<Func<Track, bool>> expression)
        {
            IQueryable<Track> tracks = GetByQuery(expression);
            return tracks.Include(x => x.Artist).OrderBy(x => x.TrackId);
        }

        public ExtendedList<Track> GetAll(TrackQueryParameters trackQueryParameters)
        {
            return ExtendedList<Track>.ToExtendedList(GetAll(),
                trackQueryParameters.PageNumber,
                trackQueryParameters.PageSize);
        }
    }
}
