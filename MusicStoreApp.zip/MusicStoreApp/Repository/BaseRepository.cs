﻿using MusicStoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MusicStoreApp.Repository.Contracts;

namespace MusicStoreApp.Repository
{
    public abstract class BaseRepository<T> : IRepository<T> where T : class
    {
        protected MusicStoreDBContext musicStoreDBContext { get; set; }

        public BaseRepository(MusicStoreDBContext  musicStoreDBContext)
        {
            this.musicStoreDBContext = musicStoreDBContext;
        }

        public IQueryable<T> GetAll()
        {
            return this.musicStoreDBContext.Set<T>()
                .AsNoTracking();
        }

        public IQueryable<T> GetByQuery(Expression<Func<T, bool>> expression)
        {
            return musicStoreDBContext.Set<T>()
                .Where(expression)
                .AsNoTracking();
        }
    }
}
