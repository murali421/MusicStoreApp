﻿using MusicStoreApp.LogService.Contracts;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStoreApp.LogService
{
    public class LoggerManager : ILoggerManager
    {
        private static ILogger logger = LogManager.GetCurrentClassLogger();

        public LoggerManager()
        {
        }

        public void Log(LogType logType, string message)
        {
            switch (logType)
            {
                case LogType.Info:
                    logger.Info(message);
                    break;
                case LogType.Debug:
                    logger.Debug(message);
                    break;
                case LogType.Warning:
                    logger.Warn(message);
                    break;
                case LogType.Error:
                    logger.Error(message);
                    break;
                default: break;
            }
        }
    }
}
