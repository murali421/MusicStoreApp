﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStoreApp.LogService
{
    public enum LogType
    {
        Info,
        Debug,
        Warning,
        Error
    }
}
