﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicStoreApp.LogService.Contracts
{
    public interface ILoggerManager
    {
        void Log(LogType logType, string message);        
    }
}
