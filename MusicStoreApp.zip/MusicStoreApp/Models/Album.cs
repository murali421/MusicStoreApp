﻿using System;
using System.Collections.Generic;

namespace MusicStoreApp.Models
{
    public partial class Album
    {
        public int AlbumId { get; set; }
        public string Name { get; set; }
        public string Review { get; set; }
        public decimal Rating { get; set; }
        public int? CommentsCount { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string Address { get; set; }
        public decimal Cost { get; set; }
        public int? GenreId { get; set; }

        public virtual Genre Genre { get; set; }
    }
}
