﻿using System;
using System.Collections.Generic;

namespace MusicStoreApp.Models
{
    public partial class Artist
    {
        public Artist()
        {
            Tracks = new HashSet<Track>();
        }

        public int ArtistId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Track> Tracks { get; set; }
    }
}
