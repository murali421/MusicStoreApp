﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicStoreApp.Entities;
using MusicStoreApp.LogService;
using MusicStoreApp.LogService.Contracts;
using MusicStoreApp.Models;
using MusicStoreApp.Repository;
using Newtonsoft.Json;
using System.Linq.Dynamic.Core;

namespace MusicStoreApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TracksController : ControllerBase
    {
        private readonly MusicStoreDBContext _context;
        private readonly ILoggerManager _logger;
        private readonly IRepositoryFacade _repositoryFacade;

        public TracksController(MusicStoreDBContext context, IRepositoryFacade repositoryFacade, ILoggerManager logger)
        {
            _context = context;
            _repositoryFacade = repositoryFacade;
            _logger = logger;
        }

        // GET: api/Tracks
        [HttpGet]
        public IActionResult GetTracks([FromQuery] TrackQueryParameters queryParameters)
        {
            IQueryable<Track> tracks = null;
            if (string.IsNullOrEmpty(queryParameters.Name))
                tracks = _repositoryFacade.Track.Get();
            else
                tracks = ApplySearch(queryParameters);

            ApplySort(ref tracks, queryParameters.OrderBy);

            var result = ExtendedList<Track>.ToExtendedList(tracks, queryParameters.PageNumber, queryParameters.PageSize);

            var metadata = new
            {
                result.TotalCount,
                result.PageSize,
                result.CurrentPage,
                result.TotalPages
            };

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(metadata));

            _logger.Log(LogType.Debug, $"Total Count: {result.TotalCount}");

            return Ok(result.ToList());
        }

        private IQueryable<Track> ApplySearch(TrackQueryParameters queryParameters)
        {
            if (!string.IsNullOrEmpty(queryParameters.Name))
            {
                return _repositoryFacade.Track.GetByExpression(track => track.Name.Contains(queryParameters.Name));
            }
            return null;
        }

        // GET: api/Tracks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Track>> GetTrack(int id)
        {
            var track = await _context.Tracks.FindAsync(id);

            if (track == null)
            {
                return NotFound();
            }

            return track;
        }

        // PUT: api/Tracks/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTrack(int id, Track track)
        {
            if (id != track.TrackId)
            {
                return BadRequest();
            }

            _context.Entry(track).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TrackExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Tracks
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Track>> PostTrack(Track track)
        {
            _context.Tracks.Add(track);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTrack", new { id = track.TrackId }, track);
        }

        // DELETE: api/Tracks/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Track>> DeleteTrack(int id)
        {
            var track = await _context.Tracks.FindAsync(id);
            if (track == null)
            {
                return NotFound();
            }

            _context.Tracks.Remove(track);
            await _context.SaveChangesAsync();

            return track;
        }

        private bool TrackExists(int id)
        {
            return _context.Tracks.Any(e => e.TrackId == id);
        }

        private void ApplySort(ref IQueryable<Track> tracks, string orderByQueryString)
        {
            
            if (tracks == null || !tracks.Any())
                return;

            if (string.IsNullOrWhiteSpace(orderByQueryString))
            {
                tracks = tracks.OrderBy(x => x.Name);
                return;
            }

            var orderParams = orderByQueryString.Trim().Split(',');
            var propertyInfos = typeof(Track).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            var orderQueryBuilder = new StringBuilder();

            foreach (var param in orderParams)
            {
                if (string.IsNullOrWhiteSpace(param))
                    continue;

                var propertyFromQueryName = param.Split(" ")[0];
                var objectProperty = propertyInfos.FirstOrDefault(pi => pi.Name.Equals(propertyFromQueryName, StringComparison.InvariantCultureIgnoreCase));

                if (objectProperty == null)
                    continue;

                var sortingOrder = param.EndsWith(" desc") ? "descending" : "ascending";

                orderQueryBuilder.Append($"{objectProperty.Name.ToString()} {sortingOrder}, ");
            }

            var orderQuery = orderQueryBuilder.ToString().TrimEnd(',', ' ');

            if (string.IsNullOrWhiteSpace(orderQuery))
            {
                tracks = tracks.OrderBy(x => x.Name);
                return;
            }

            tracks = tracks.OrderBy(orderQuery);
        }
    }
}
